//
//  expensorTests.swift
//  expensorTests
//
//  Created by Sebastian Pavel on 18.05.2025.
//

import Testing
@testable import expensor

struct expensorTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
